Tweet_JSON contains all tweets in json format


newFullTime
rumorsFullTime

contain all stories’s tweets since 2008


{"contain_photos_number": 0, "hashtags": [], "contain_photos": false, "menstion": ["16955991", "16955991"], "user_screen_name": "Snarkaroni", "retweet_from_userid": null, "contain_videos": false, "retweets": 1, "isretweet": false, "text": "Remove this post, @Salon. Hoax!\nTwitter explodes at Ammon Bundy after he compares himself to Rosa Parks http://www.salon.com/2016/01/06/twitter_explodes_at_ammon_bundy_after_he_compares_himself_to_rosa_parks/ … via @Salon", "retweet_from_tweetid": null, "contain_photos_url": [], "urls": ["http://www.salon.com/2016/01/06/twitter_explodes_at_ammon_bundy_after_he_compares_himself_to_rosa_parks/"], "user_id": "765357788", "user_name": "Snarkaroni™", "created_at": 1452124177000.0, "tweet_id": "684884557972176897", "favorites": 0}

____________________________***********************_____________________________

news
rumors 
contains tweets only in the event time( 48 hours) and one more feature “extend_urls” 

{"contain_photos_number": 0, "contain_videos": false, "contain_photos_url": [], "extend_urls": ["www.bbc.co.uk"], "urls": ["http://bbc.in/17QhmS3"], "tweet_id": "371035770204598272", "created_at": 1377296795000.0, "hashtags": [], "text": "'Alien' gargoyle on ancient Paisley Abbey http://bbc.in/17QhmS3\u00a0", "user_id": "62341949", "retweet_from_userid": null, "retweets": 2, "user_name": "Claire Butler", "user_screen_name": "CLButler76", "contain_photos": false, "retweet_from_tweetid": null, "isretweet": false, "menstion": [], "favorites": 1}


____________________________***********************_____________________________
Features contains feature abstracted from tweet

example of format in the the example.txt






